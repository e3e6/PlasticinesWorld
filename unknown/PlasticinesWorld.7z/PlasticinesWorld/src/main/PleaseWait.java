package main;

import java.awt.HeadlessException;

import javax.swing.JButton;
import javax.swing.JFrame;

public class PleaseWait extends JFrame {

	public PleaseWait(String title) throws HeadlessException {
		super(title);
		
		add(new JButton("Press me"));
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
		setVisible(true);
		
	}

}
