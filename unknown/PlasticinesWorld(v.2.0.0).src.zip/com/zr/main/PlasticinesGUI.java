/*   1:    */ package com.zr.main;
/*   2:    */ 
/*   3:    */ import com.zr.components.FileSystemTree;
/*   4:    */ import com.zr.components.StreamViewer;
/*   5:    */ import com.zr.controller.Controller;
/*   6:    */ import com.zr.model.dto.Task;
/*   7:    */ import com.zr.model.table.FileDTOTableModel;
/*   8:    */ import com.zr.model.table.TaskReportTableModel;
/*   9:    */ import java.awt.Component;
/*  10:    */ import java.awt.Font;
/*  11:    */ import java.awt.GridBagConstraints;
/*  12:    */ import java.awt.GridBagLayout;
/*  13:    */ import java.awt.HeadlessException;
/*  14:    */ import java.awt.Insets;
/*  15:    */ import java.io.File;
/*  16:    */ import java.io.PrintStream;
/*  17:    */ import javax.swing.JFrame;
/*  18:    */ import javax.swing.JLabel;
/*  19:    */ import javax.swing.JPanel;
/*  20:    */ import javax.swing.JScrollPane;
/*  21:    */ import javax.swing.JSplitPane;
/*  22:    */ import javax.swing.JTable;
/*  23:    */ import javax.swing.JTextField;
/*  24:    */ import javax.swing.JTree;
/*  25:    */ import javax.swing.ListSelectionModel;
/*  26:    */ import javax.swing.UIManager;
/*  27:    */ import javax.swing.event.ListSelectionEvent;
/*  28:    */ import javax.swing.event.ListSelectionListener;
/*  29:    */ import javax.swing.event.TableModelEvent;
/*  30:    */ import javax.swing.event.TableModelListener;
/*  31:    */ import javax.swing.table.TableModel;
/*  32:    */ import javax.swing.tree.TreePath;
/*  33:    */ 
/*  34:    */ public class PlasticinesGUI
/*  35:    */   extends JFrame
/*  36:    */ {
/*  37:    */   private static final long serialVersionUID = 4866064772639069191L;
/*  38:    */   private JTree fileSystemTree;
/*  39:    */   private JTable fileListTable;
/*  40:    */   private JTable workingListTable;
/*  41:    */   private StreamViewer textArea;
/*  42:    */   private JTextField pathTextField;
/*  43:    */   
/*  44:    */   public PlasticinesGUI(String title)
/*  45:    */     throws HeadlessException
/*  46:    */   {
/*  47: 64 */     super(title);
/*  48: 65 */     setDefaultCloseOperation(3);
/*  49:    */     
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53: 70 */     JSplitPane verticalSplitPane = new JSplitPane(0);
/*  54: 71 */     verticalSplitPane.setLeftComponent(createWorkingListPanel());
/*  55: 72 */     verticalSplitPane.setRightComponent(createLogViewPanel());
/*  56:    */     
/*  57:    */ 
/*  58: 75 */     JSplitPane secondSplit = new JSplitPane(1);
/*  59: 76 */     secondSplit.setLeftComponent(createFilesListPanel());
/*  60: 77 */     secondSplit.setRightComponent(verticalSplitPane);
/*  61:    */     
/*  62:    */ 
/*  63: 80 */     JSplitPane mainSplit = new JSplitPane(1);
/*  64:    */     
/*  65: 82 */     mainSplit.setLeftComponent(createFileTreePanel());
/*  66: 83 */     mainSplit.setRightComponent(secondSplit);
/*  67:    */     
/*  68: 85 */     add(mainSplit);
/*  69: 86 */     pack();
/*  70: 87 */     decorate();
/*  71:    */   }
/*  72:    */   
/*  73:    */   private void decorate()
/*  74:    */   {
/*  75: 93 */     Font mono = new Font("Monospaced", 0, getFont().getSize());
/*  76:    */     
/*  77: 95 */     this.fileListTable.setFont(mono);
/*  78: 96 */     this.workingListTable.setFont(mono);
/*  79:    */     
/*  80: 98 */     this.textArea.setFont(mono);
/*  81: 99 */     setFont(mono);
/*  82:    */   }
/*  83:    */   
/*  84:    */   private Component createFilesListPanel()
/*  85:    */   {
/*  86:109 */     this.fileListTable = new JTable(new FileDTOTableModel());
/*  87:110 */     this.fileListTable.setToolTipText("Двойной щелчёк по файлу для запуска задачи.");
/*  88:    */     
/*  89:    */ 
/*  90:113 */     JPanel panel = new JPanel(new GridBagLayout());
/*  91:114 */     panel.add(new JLabel("Фильтр"), new GridBagConstraints(0, 0, 1, 1, 0.0D, 0.0D, 17, 0, new Insets(2, 2, 2, 2), 0, 0));
/*  92:115 */     panel.add(new JTextField(""), new GridBagConstraints(1, 0, 1, 1, 1.0D, 0.0D, 17, 2, new Insets(2, 2, 2, 2), 0, 5));
/*  93:116 */     panel.add(new JScrollPane(this.fileListTable), new GridBagConstraints(0, 1, 2, 1, 1.0D, 1.0D, 17, 1, new Insets(0, 0, 0, 0), 0, 0));
/*  94:    */     
/*  95:118 */     return panel;
/*  96:    */   }
/*  97:    */   
/*  98:    */   private Component createFileTreePanel()
/*  99:    */   {
/* 100:127 */     this.fileSystemTree = new FileSystemTree();
/* 101:    */     
/* 102:129 */     this.pathTextField = new JTextField(20);
/* 103:130 */     this.pathTextField.setToolTipText("Paste or edit path and press [Enter]");
/* 104:    */     
/* 105:132 */     JPanel panel = new JPanel(new GridBagLayout());
/* 106:    */     
/* 107:134 */     panel.add(this.pathTextField, new GridBagConstraints(0, 0, 1, 1, 1.0D, 0.0D, 17, 2, new Insets(2, 2, 2, 2), 0, 5));
/* 108:135 */     panel.add(new JScrollPane(this.fileSystemTree), new GridBagConstraints(0, 1, 1, 1, 1.0D, 1.0D, 17, 1, new Insets(0, 0, 0, 0), 0, 0));
/* 109:    */     
/* 110:137 */     return panel;
/* 111:    */   }
/* 112:    */   
/* 113:    */   private Component createLogViewPanel()
/* 114:    */   {
/* 115:146 */     this.textArea = new StreamViewer();
/* 116:    */     
/* 117:148 */     return new JScrollPane(this.textArea);
/* 118:    */   }
/* 119:    */   
/* 120:    */   private Component createWorkingListPanel()
/* 121:    */   {
/* 122:156 */     this.workingListTable = new JTable(new TaskReportTableModel());
/* 123:    */     
/* 124:158 */     this.workingListTable.getSelectionModel().addListSelectionListener(new ListSelectionListener()
/* 125:    */     {
/* 126:    */       public void valueChanged(ListSelectionEvent e)
/* 127:    */       {
/* 128:163 */         Task task = ((TaskReportTableModel)PlasticinesGUI.this.workingListTable.getModel()).getObjectAt(PlasticinesGUI.this.workingListTable.getSelectedRow());
/* 129:    */         
/* 130:165 */         PlasticinesGUI.this.textArea.setDataSource(task);
/* 131:    */       }
/* 132:169 */     });
/* 133:170 */     this.workingListTable.getModel().addTableModelListener(new TableModelListener()
/* 134:    */     {
/* 135:    */       public void tableChanged(TableModelEvent e)
/* 136:    */       {
/* 137:174 */         if (e.getType() == 1) {
/* 138:176 */           if (PlasticinesGUI.this.workingListTable.getSelectedRow() == -1) {
/* 139:177 */             PlasticinesGUI.this.workingListTable.setRowSelectionInterval(PlasticinesGUI.this.workingListTable.getRowCount() - 1, PlasticinesGUI.this.workingListTable.getRowCount() - 1);
/* 140:    */           }
/* 141:    */         }
/* 142:    */       }
/* 143:182 */     });
/* 144:183 */     return new JScrollPane(this.workingListTable);
/* 145:    */   }
/* 146:    */   
/* 147:    */   public void updateFileList(File file)
/* 148:    */   {
/* 149:187 */     this.pathTextField.setText(((File)this.fileSystemTree.getSelectionPath().getLastPathComponent()).getAbsolutePath());
/* 150:    */     
/* 151:189 */     ((FileDTOTableModel)this.fileListTable.getModel()).setDataSource(file);
/* 152:    */   }
/* 153:    */   
/* 154:    */   public void addListeners(Controller controller)
/* 155:    */   {
/* 156:194 */     this.fileSystemTree.addTreeSelectionListener(controller);
/* 157:    */     
/* 158:196 */     this.pathTextField.addKeyListener(controller);
/* 159:    */     
/* 160:198 */     this.fileListTable.addMouseListener(controller);
/* 161:    */   }
/* 162:    */   
/* 163:    */   public JTable getWorkingListTable()
/* 164:    */   {
/* 165:203 */     return this.workingListTable;
/* 166:    */   }
/* 167:    */   
/* 168:    */   public void showPath()
/* 169:    */   {
/* 170:210 */     String path = this.pathTextField.getText();
/* 171:    */     
/* 172:212 */     ((FileSystemTree)this.fileSystemTree).showFile(new File(path));
/* 173:    */   }
/* 174:    */   
/* 175:    */   public static void main(String[] args)
/* 176:    */   {
/* 177:    */     try
/* 178:    */     {
/* 179:220 */       UIManager.setLookAndFeel("com.sun.java.swing.plaf.gtk.GTKLookAndFeel");
/* 180:    */     }
/* 181:    */     catch (Throwable thrown)
/* 182:    */     {
/* 183:223 */       System.err.println("Can't set LaF");
/* 184:    */     }
/* 185:226 */     PlasticinesGUI gui = new PlasticinesGUI("Пластилины мира v.2.0");
/* 186:    */     
/* 187:228 */     new Controller(gui);
/* 188:    */     
/* 189:230 */     gui.setVisible(true);
/* 190:    */   }
/* 191:    */ }


/* Location:           D:\.desktop\PlasticinesWorld(v.2.0.0).jar
 * Qualified Name:     com.zr.main.PlasticinesGUI
 * JD-Core Version:    0.7.0.1
 */