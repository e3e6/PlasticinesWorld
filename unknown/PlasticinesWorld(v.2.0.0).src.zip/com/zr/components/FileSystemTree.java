/*  1:   */ package com.zr.components;
/*  2:   */ 
/*  3:   */ import com.zr.model.tree.FileSystemTreeModel;
/*  4:   */ import java.io.File;
/*  5:   */ import java.util.ArrayList;
/*  6:   */ import java.util.List;
/*  7:   */ import javax.swing.JTree;
/*  8:   */ import javax.swing.tree.TreePath;
/*  9:   */ 
/* 10:   */ public class FileSystemTree
/* 11:   */   extends JTree
/* 12:   */ {
/* 13:   */   private static final long serialVersionUID = 2642528775427615193L;
/* 14:   */   
/* 15:   */   public FileSystemTree()
/* 16:   */   {
/* 17:22 */     setModel(new FileSystemTreeModel());
/* 18:   */   }
/* 19:   */   
/* 20:   */   public String convertValueToText(Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus)
/* 21:   */   {
/* 22:30 */     if (value.getClass() == File.class)
/* 23:   */     {
/* 24:32 */       if (((File)value).getParent() == null) {
/* 25:33 */         return ((File)value).getPath();
/* 26:   */       }
/* 27:35 */       return ((File)value).getName();
/* 28:   */     }
/* 29:41 */     return value.toString();
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void showFile(File dir)
/* 33:   */   {
/* 34:52 */     if (dir.isFile()) {
/* 35:52 */       dir = dir.getParentFile();
/* 36:   */     }
/* 37:54 */     if (dir.isDirectory())
/* 38:   */     {
/* 39:56 */       List<File> pathElement = new ArrayList();
/* 40:59 */       while (dir.getParent() != null)
/* 41:   */       {
/* 42:60 */         pathElement.add(dir.getAbsoluteFile());
/* 43:   */         
/* 44:62 */         dir = dir.getParentFile();
/* 45:   */       }
/* 46:64 */       pathElement.add(dir.getAbsoluteFile());
/* 47:   */       
/* 48:   */ 
/* 49:   */ 
/* 50:   */ 
/* 51:69 */       List<Object> treePath = new ArrayList();
/* 52:70 */       treePath.add(FileSystemTreeModel.ROOT);
/* 53:72 */       for (int i = pathElement.size() - 1; i >= 0; i--)
/* 54:   */       {
/* 55:74 */         treePath.add(pathElement.get(i));
/* 56:   */         
/* 57:76 */         TreePath tree = new TreePath(treePath.toArray());
/* 58:   */         
/* 59:78 */         setSelectionPath(tree);
/* 60:79 */         scrollPathToVisible(tree);
/* 61:   */       }
/* 62:   */     }
/* 63:   */   }
/* 64:   */ }


/* Location:           D:\.desktop\PlasticinesWorld(v.2.0.0).jar
 * Qualified Name:     com.zr.components.FileSystemTree
 * JD-Core Version:    0.7.0.1
 */