/*  1:   */ package com.zr.components;
/*  2:   */ 
/*  3:   */ import com.zr.model.dto.Task;
/*  4:   */ import java.awt.Font;
/*  5:   */ import java.beans.PropertyChangeEvent;
/*  6:   */ import java.beans.PropertyChangeListener;
/*  7:   */ import javax.swing.JTextArea;
/*  8:   */ import javax.swing.text.Document;
/*  9:   */ 
/* 10:   */ public class StreamViewer
/* 11:   */   extends JTextArea
/* 12:   */   implements PropertyChangeListener
/* 13:   */ {
/* 14:   */   private Task dataSource;
/* 15:   */   private static final long serialVersionUID = 8220608505603091674L;
/* 16:   */   
/* 17:   */   public StreamViewer()
/* 18:   */   {
/* 19:22 */     setFont(new Font("Monospaced", 0, getFont().getSize()));
/* 20:   */   }
/* 21:   */   
/* 22:   */   public StreamViewer(int rows, int columns)
/* 23:   */   {
/* 24:26 */     super(rows, columns);setFont(new Font("Monospaced", 0, getFont().getSize()));
/* 25:   */   }
/* 26:   */   
/* 27:   */   public synchronized void setDataSource(Task task)
/* 28:   */   {
/* 29:39 */     if (this.dataSource != null) {
/* 30:40 */       this.dataSource.removePropertyChangeListener(this);
/* 31:   */     }
/* 32:44 */     this.dataSource = task;
/* 33:45 */     this.dataSource.addPropertyChangeListener(this);
/* 34:   */     
/* 35:47 */     setText(getDataSource().getStreamOut().toString());
/* 36:   */   }
/* 37:   */   
/* 38:   */   public synchronized Task getDataSource()
/* 39:   */   {
/* 40:52 */     return this.dataSource;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public void propertyChange(PropertyChangeEvent evt)
/* 44:   */   {
/* 45:57 */     setText(getDataSource().getStreamOut().toString());
/* 46:   */     
/* 47:   */ 
/* 48:60 */     setCaretPosition(getDocument().getLength());
/* 49:   */   }
/* 50:   */ }


/* Location:           D:\.desktop\PlasticinesWorld(v.2.0.0).jar
 * Qualified Name:     com.zr.components.StreamViewer
 * JD-Core Version:    0.7.0.1
 */