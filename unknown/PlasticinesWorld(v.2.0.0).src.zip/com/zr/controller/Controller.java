/*  1:   */ package com.zr.controller;
/*  2:   */ 
/*  3:   */ import com.zr.main.PlasticinesGUI;
/*  4:   */ import com.zr.model.ExecutiveManager;
/*  5:   */ import com.zr.model.dto.FileDTO;
/*  6:   */ import com.zr.model.table.FileDTOTableModel;
/*  7:   */ import java.awt.event.KeyEvent;
/*  8:   */ import java.awt.event.KeyListener;
/*  9:   */ import java.awt.event.MouseEvent;
/* 10:   */ import java.awt.event.MouseListener;
/* 11:   */ import java.io.File;
/* 12:   */ import javax.swing.JTable;
/* 13:   */ import javax.swing.event.TreeSelectionEvent;
/* 14:   */ import javax.swing.event.TreeSelectionListener;
/* 15:   */ import javax.swing.tree.TreePath;
/* 16:   */ 
/* 17:   */ public class Controller
/* 18:   */   implements TreeSelectionListener, KeyListener, MouseListener
/* 19:   */ {
/* 20:   */   private PlasticinesGUI view;
/* 21:   */   private ExecutiveManager manager;
/* 22:   */   
/* 23:   */   public Controller(PlasticinesGUI view)
/* 24:   */   {
/* 25:25 */     this.view = view;
/* 26:26 */     this.manager = new ExecutiveManager(view.getWorkingListTable());
/* 27:   */     
/* 28:28 */     view.addListeners(this);
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void valueChanged(TreeSelectionEvent e)
/* 32:   */   {
/* 33:35 */     TreePath path = e.getNewLeadSelectionPath();
/* 34:37 */     if ((path != null) && (path.getPathCount() > 1)) {
/* 35:39 */       this.view.updateFileList((File)path.getLastPathComponent());
/* 36:   */     }
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void keyTyped(KeyEvent e) {}
/* 40:   */   
/* 41:   */   public void keyPressed(KeyEvent e)
/* 42:   */   {
/* 43:55 */     if (e.getKeyCode() == 10) {
/* 44:56 */       this.view.showPath();
/* 45:   */     }
/* 46:   */   }
/* 47:   */   
/* 48:   */   public void keyReleased(KeyEvent e) {}
/* 49:   */   
/* 50:   */   public void mouseClicked(MouseEvent e)
/* 51:   */   {
/* 52:72 */     Object source = e.getSource();
/* 53:74 */     if ((e.getClickCount() == 2) && 
/* 54:75 */       (source.getClass().equals(JTable.class)))
/* 55:   */     {
/* 56:76 */       JTable table = (JTable)source;
/* 57:   */       
/* 58:78 */       FileDTO dto = ((FileDTOTableModel)table.getModel()).getObjectAt(table.getSelectedRow());
/* 59:   */       
/* 60:80 */       this.manager.addTask(dto.getFileName().getName(), dto.toCommandString());
/* 61:   */     }
/* 62:   */   }
/* 63:   */   
/* 64:   */   public void mousePressed(MouseEvent e) {}
/* 65:   */   
/* 66:   */   public void mouseReleased(MouseEvent e) {}
/* 67:   */   
/* 68:   */   public void mouseEntered(MouseEvent e) {}
/* 69:   */   
/* 70:   */   public void mouseExited(MouseEvent e) {}
/* 71:   */ }


/* Location:           D:\.desktop\PlasticinesWorld(v.2.0.0).jar
 * Qualified Name:     com.zr.controller.Controller
 * JD-Core Version:    0.7.0.1
 */