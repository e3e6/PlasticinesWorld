/*   1:    */ package com.zr.model.dto;
/*   2:    */ 
/*   3:    */ import java.beans.PropertyChangeListener;
/*   4:    */ import java.beans.PropertyChangeSupport;
/*   5:    */ import java.io.BufferedReader;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.InputStreamReader;
/*   8:    */ import java.io.PrintStream;
/*   9:    */ import java.text.SimpleDateFormat;
/*  10:    */ import java.util.Calendar;
/*  11:    */ 
/*  12:    */ public class Task
/*  13:    */   extends Thread
/*  14:    */ {
/*  15:    */   private String taskName;
/*  16:    */   private Calendar startTime;
/*  17:    */   private Calendar endTime;
/*  18:    */   private String cmd;
/*  19: 37 */   StringBuffer streamOut = new StringBuffer();
/*  20: 43 */   private PropertyChangeSupport changes = new PropertyChangeSupport(this);
/*  21:    */   private static final String DEFAULT_CODEPAGE = "cp866";
/*  22:    */   
/*  23:    */   public Task(String name, String cmd)
/*  24:    */   {
/*  25: 50 */     this.taskName = name;
/*  26: 51 */     this.cmd = cmd;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void run()
/*  30:    */   {
/*  31: 57 */     this.startTime = Calendar.getInstance();
/*  32: 58 */     printToStream(new SimpleDateFormat("HH.mm.ss").format(this.startTime.getTime()) + ">> " + this.cmd);
/*  33:    */     try
/*  34:    */     {
/*  35: 61 */       Process process = Runtime.getRuntime().exec(this.cmd);
/*  36:    */       
/*  37: 63 */       BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream(), "cp866"));
/*  38:    */       String line;
/*  39: 66 */       while ((line = br.readLine()) != null)
/*  40:    */       {
/*  41:    */         String line;
/*  42: 67 */         printToStream(line);
/*  43:    */       }
/*  44:    */     }
/*  45:    */     catch (IOException e)
/*  46:    */     {
/*  47: 71 */       System.err.println(e.getMessage());
/*  48:    */     }
/*  49: 74 */     this.endTime = Calendar.getInstance();
/*  50:    */   }
/*  51:    */   
/*  52:    */   public String getStdOut()
/*  53:    */   {
/*  54: 80 */     return "";
/*  55:    */   }
/*  56:    */   
/*  57:    */   public String getTaskName()
/*  58:    */   {
/*  59: 85 */     return this.taskName;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setTaskName(String taskName)
/*  63:    */   {
/*  64: 90 */     this.taskName = taskName;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public Calendar getStartTime()
/*  68:    */   {
/*  69: 95 */     return this.startTime;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setStartTime(Calendar startTime)
/*  73:    */   {
/*  74:100 */     this.startTime = startTime;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public Calendar getEndTime()
/*  78:    */   {
/*  79:105 */     return this.endTime;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void setEndTime(Calendar endTime)
/*  83:    */   {
/*  84:110 */     this.endTime = endTime;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public StringBuffer getStreamOut()
/*  88:    */   {
/*  89:114 */     return this.streamOut;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void setStreamOut(StringBuffer streamOut)
/*  93:    */   {
/*  94:118 */     this.streamOut = streamOut;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void printToStream(String string)
/*  98:    */   {
/*  99:122 */     String old = this.streamOut.toString();
/* 100:    */     
/* 101:124 */     this.streamOut.append(string).append(System.getProperty("line.separator"));
/* 102:    */     
/* 103:126 */     this.changes.firePropertyChange("streamWrite", old, this.streamOut.toString());
/* 104:    */   }
/* 105:    */   
/* 106:    */   public void addPropertyChangeListener(PropertyChangeListener l)
/* 107:    */   {
/* 108:130 */     this.changes.addPropertyChangeListener(l);
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void removePropertyChangeListener(PropertyChangeListener l)
/* 112:    */   {
/* 113:134 */     this.changes.removePropertyChangeListener(l);
/* 114:    */   }
/* 115:    */ }


/* Location:           D:\.desktop\PlasticinesWorld(v.2.0.0).jar
 * Qualified Name:     com.zr.model.dto.Task
 * JD-Core Version:    0.7.0.1
 */