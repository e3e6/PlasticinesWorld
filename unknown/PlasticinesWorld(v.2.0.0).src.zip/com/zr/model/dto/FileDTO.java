/*  1:   */ package com.zr.model.dto;
/*  2:   */ 
/*  3:   */ import java.io.File;
/*  4:   */ import java.util.StringTokenizer;
/*  5:   */ 
/*  6:   */ public class FileDTO
/*  7:   */ {
/*  8:   */   String commandName;
/*  9:   */   File file;
/* 10:   */   String params;
/* 11:   */   
/* 12:   */   public FileDTO(File fileName)
/* 13:   */   {
/* 14:23 */     this.commandName = "";
/* 15:24 */     this.file = fileName;
/* 16:25 */     this.params = "";
/* 17:   */     
/* 18:   */ 
/* 19:28 */     String ext = parseExtension(fileName.getName());
/* 20:30 */     if (ext.equals("java")) {
/* 21:31 */       this.commandName = "javaw";
/* 22:32 */     } else if (ext.equals("bat")) {
/* 23:33 */       this.commandName = "";
/* 24:34 */     } else if (ext.equals("vbs")) {
/* 25:35 */       this.commandName = "cscript";
/* 26:   */     }
/* 27:   */   }
/* 28:   */   
/* 29:   */   public FileDTO(String commandName, File fileName, String params)
/* 30:   */   {
/* 31:43 */     this.commandName = commandName;
/* 32:44 */     this.file = fileName;
/* 33:45 */     this.params = params;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public String getCommandName()
/* 37:   */   {
/* 38:49 */     return this.commandName;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void setCommandName(String commandName)
/* 42:   */   {
/* 43:52 */     this.commandName = commandName;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public File getFileName()
/* 47:   */   {
/* 48:55 */     return this.file;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public void setFileName(File fileName)
/* 52:   */   {
/* 53:58 */     this.file = fileName;
/* 54:   */   }
/* 55:   */   
/* 56:   */   public String getParams()
/* 57:   */   {
/* 58:61 */     return this.params;
/* 59:   */   }
/* 60:   */   
/* 61:   */   public void setParams(String params)
/* 62:   */   {
/* 63:64 */     this.params = params;
/* 64:   */   }
/* 65:   */   
/* 66:   */   public String toString()
/* 67:   */   {
/* 68:69 */     StringBuilder sb = new StringBuilder();
/* 69:   */     
/* 70:71 */     sb.append(this.commandName).append(" ");
/* 71:72 */     sb.append(this.file.getAbsolutePath()).append(" ");
/* 72:73 */     sb.append(this.params);
/* 73:   */     
/* 74:75 */     return sb.toString();
/* 75:   */   }
/* 76:   */   
/* 77:   */   public String toCommandString()
/* 78:   */   {
/* 79:80 */     StringBuilder sb = new StringBuilder();
/* 80:   */     
/* 81:82 */     sb.append(this.commandName).append(" ");
/* 82:83 */     sb.append("\"").append(this.file.getAbsolutePath()).append("\" ");
/* 83:84 */     sb.append(this.params);
/* 84:   */     
/* 85:86 */     return sb.toString();
/* 86:   */   }
/* 87:   */   
/* 88:   */   private String parseExtension(String fileName)
/* 89:   */   {
/* 90:90 */     StringTokenizer st = new StringTokenizer(fileName, ".");
/* 91:   */     
/* 92:92 */     String s = "";
/* 93:93 */     while (st.hasMoreTokens()) {
/* 94:94 */       s = st.nextToken();
/* 95:   */     }
/* 96:97 */     return s;
/* 97:   */   }
/* 98:   */ }


/* Location:           D:\.desktop\PlasticinesWorld(v.2.0.0).jar
 * Qualified Name:     com.zr.model.dto.FileDTO
 * JD-Core Version:    0.7.0.1
 */