/*   1:    */ package com.zr.model.dto;
/*   2:    */ 
/*   3:    */ import java.io.BufferedReader;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.io.InputStream;
/*   6:    */ import java.io.InputStreamReader;
/*   7:    */ 
/*   8:    */ class Streamer
/*   9:    */   extends Thread
/*  10:    */ {
/*  11:    */   private InputStream input;
/*  12:    */   private StringBuffer sbuffer;
/*  13:    */   
/*  14:    */   public Streamer(InputStream in, StringBuffer sb)
/*  15:    */   {
/*  16:148 */     this.input = in;
/*  17:149 */     this.sbuffer = sb;
/*  18:    */   }
/*  19:    */   
/*  20:    */   public void run()
/*  21:    */   {
/*  22:    */     try
/*  23:    */     {
/*  24:154 */       BufferedReader reader = new BufferedReader(new InputStreamReader(this.input));
/*  25:155 */       String line = null;
/*  26:157 */       while ((line = reader.readLine()) != null) {
/*  27:158 */         this.sbuffer.append(line);
/*  28:    */       }
/*  29:    */     }
/*  30:    */     catch (IOException ioe)
/*  31:    */     {
/*  32:161 */       ioe.printStackTrace();
/*  33:    */     }
/*  34:    */   }
/*  35:    */ }


/* Location:           D:\.desktop\PlasticinesWorld(v.2.0.0).jar
 * Qualified Name:     com.zr.model.dto.Streamer
 * JD-Core Version:    0.7.0.1
 */