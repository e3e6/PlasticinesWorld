/*  1:   */ package com.zr.model.tree;
/*  2:   */ 
/*  3:   */ import java.io.File;
/*  4:   */ import java.io.FileFilter;
/*  5:   */ import java.util.Arrays;
/*  6:   */ import javax.swing.event.TreeModelListener;
/*  7:   */ import javax.swing.tree.TreeModel;
/*  8:   */ import javax.swing.tree.TreePath;
/*  9:   */ 
/* 10:   */ public class FileSystemTreeModel
/* 11:   */   implements TreeModel
/* 12:   */ {
/* 13:   */   public Object getRoot()
/* 14:   */   {
/* 15:15 */     return ROOT;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public Object getChild(Object parent, int index)
/* 19:   */   {
/* 20:20 */     return parent.toString().equals(ROOT) ? File.listRoots()[index] : getChildsDir(parent)[index];
/* 21:   */   }
/* 22:   */   
/* 23:   */   public int getChildCount(Object parent)
/* 24:   */   {
/* 25:25 */     return parent.toString().equals(ROOT) ? File.listRoots().length : getChildsDir(parent).length;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public boolean isLeaf(Object node)
/* 29:   */   {
/* 30:30 */     return false;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public void valueForPathChanged(TreePath path, Object newValue) {}
/* 34:   */   
/* 35:   */   public int getIndexOfChild(Object parent, Object child)
/* 36:   */   {
/* 37:42 */     return Arrays.binarySearch(getChildsDir(parent), (File)child);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void addTreeModelListener(TreeModelListener l) {}
/* 41:   */   
/* 42:   */   public void removeTreeModelListener(TreeModelListener l) {}
/* 43:   */   
/* 44:   */   private File[] getChildsDir(Object parentDir)
/* 45:   */   {
/* 46:60 */     return ((File)parentDir).listFiles(DIR_FILTER);
/* 47:   */   }
/* 48:   */   
/* 49:63 */   public static final String ROOT = System.getProperty("file.separator");
/* 50:64 */   private static final FileFilter DIR_FILTER = new FileFilter()
/* 51:   */   {
/* 52:   */     public boolean accept(File pathname)
/* 53:   */     {
/* 54:68 */       if (pathname.isDirectory()) {
/* 55:70 */         return true;
/* 56:   */       }
/* 57:73 */       return false;
/* 58:   */     }
/* 59:   */   };
/* 60:   */ }


/* Location:           D:\.desktop\PlasticinesWorld(v.2.0.0).jar
 * Qualified Name:     com.zr.model.tree.FileSystemTreeModel
 * JD-Core Version:    0.7.0.1
 */