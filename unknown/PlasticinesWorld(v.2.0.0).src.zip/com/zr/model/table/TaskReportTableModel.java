/*   1:    */ package com.zr.model.table;
/*   2:    */ 
/*   3:    */ import com.zr.model.dto.Task;
/*   4:    */ import java.text.SimpleDateFormat;
/*   5:    */ import java.util.ArrayList;
/*   6:    */ import java.util.Calendar;
/*   7:    */ import java.util.List;
/*   8:    */ import javax.swing.table.AbstractTableModel;
/*   9:    */ 
/*  10:    */ public class TaskReportTableModel
/*  11:    */   extends AbstractTableModel
/*  12:    */ {
/*  13:    */   private static final long serialVersionUID = 3452073041410895000L;
/*  14:    */   private List<Task> taskList;
/*  15:    */   public static final int COLUMN_FILENAME = 0;
/*  16:    */   public static final int COLUMN_STARTTIME = 1;
/*  17:    */   public static final int COLUMN_DURATION = 2;
/*  18:    */   public static final int COLUMN_ENDTIME = 3;
/*  19:    */   
/*  20:    */   public TaskReportTableModel()
/*  21:    */   {
/*  22: 22 */     this.taskList = new ArrayList();
/*  23:    */   }
/*  24:    */   
/*  25:    */   public TaskReportTableModel(List<Task> taskList)
/*  26:    */   {
/*  27: 27 */     this.taskList = taskList;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public int getRowCount()
/*  31:    */   {
/*  32: 32 */     return this.taskList.size();
/*  33:    */   }
/*  34:    */   
/*  35:    */   public int getColumnCount()
/*  36:    */   {
/*  37: 37 */     return 4;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public String getColumnName(int column)
/*  41:    */   {
/*  42: 43 */     switch (column)
/*  43:    */     {
/*  44:    */     case 0: 
/*  45: 46 */       return "Имя файла";
/*  46:    */     case 1: 
/*  47: 50 */       return "Время запуска";
/*  48:    */     case 2: 
/*  49: 54 */       return "Продолжительность";
/*  50:    */     case 3: 
/*  51: 58 */       return "Время завершения";
/*  52:    */     }
/*  53: 62 */     return "undefined";
/*  54:    */   }
/*  55:    */   
/*  56:    */   public Task getObjectAt(int row)
/*  57:    */   {
/*  58: 72 */     return (Task)this.taskList.get(row);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public Object getValueAt(int rowIndex, int columnIndex)
/*  62:    */   {
/*  63: 78 */     switch (columnIndex)
/*  64:    */     {
/*  65:    */     case 0: 
/*  66: 81 */       return ((Task)this.taskList.get(rowIndex)).getTaskName();
/*  67:    */     case 1: 
/*  68: 85 */       return getFormattedTime(((Task)this.taskList.get(rowIndex)).getStartTime());
/*  69:    */     case 2: 
/*  70: 89 */       return countTimeDif(rowIndex);
/*  71:    */     case 3: 
/*  72: 93 */       return getFormattedTime(((Task)this.taskList.get(rowIndex)).getEndTime());
/*  73:    */     }
/*  74: 97 */     return null;
/*  75:    */   }
/*  76:    */   
/*  77:    */   private String getFormattedTime(Calendar time)
/*  78:    */   {
/*  79:106 */     if (time != null) {
/*  80:107 */       return sdf.format(time.getTime());
/*  81:    */     }
/*  82:111 */     return " - ";
/*  83:    */   }
/*  84:    */   
/*  85:    */   private String countTimeDif(int rowIndex)
/*  86:    */   {
/*  87:121 */     Calendar start = ((Task)this.taskList.get(rowIndex)).getStartTime();
/*  88:122 */     Calendar end = ((Task)this.taskList.get(rowIndex)).getEndTime();
/*  89:126 */     if (start != null)
/*  90:    */     {
/*  91:128 */       long dif = (end == null ? Calendar.getInstance().getTimeInMillis() : end.getTimeInMillis()) - start.getTimeInMillis();
/*  92:    */       
/*  93:    */ 
/*  94:131 */       double dif_s = (int)(dif / 1000L);
/*  95:133 */       if (dif_s < 60.0D) {
/*  96:134 */         return dif_s + " сек.";
/*  97:    */       }
/*  98:136 */       double dif_m = dif_s / 60.0D;
/*  99:138 */       if (dif_m < 60.0D) {
/* 100:139 */         return dif_m + " мин. ";
/* 101:    */       }
/* 102:141 */       return dif_m / 60.0D + " ч. ";
/* 103:    */     }
/* 104:148 */     return " – ";
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void setDataSource(List<Task> taskList)
/* 108:    */   {
/* 109:152 */     this.taskList = taskList;
/* 110:153 */     fireTableDataChanged();
/* 111:    */   }
/* 112:    */   
/* 113:    */   public void addRow(Task newTask)
/* 114:    */   {
/* 115:157 */     this.taskList.add(newTask);
/* 116:158 */     fireTableRowsInserted(this.taskList.size(), this.taskList.size());
/* 117:    */   }
/* 118:    */   
/* 119:    */   public void removeRow(Task remTask)
/* 120:    */   {
/* 121:163 */     int range = this.taskList.indexOf(remTask);
/* 122:    */     
/* 123:165 */     this.taskList.remove(remTask);
/* 124:166 */     fireTableRowsDeleted(range, range);
/* 125:    */   }
/* 126:    */   
/* 127:186 */   public static final SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
/* 128:    */ }


/* Location:           D:\.desktop\PlasticinesWorld(v.2.0.0).jar
 * Qualified Name:     com.zr.model.table.TaskReportTableModel
 * JD-Core Version:    0.7.0.1
 */