/*   1:    */ package com.zr.model.table;
/*   2:    */ 
/*   3:    */ import com.zr.model.dto.FileDTO;
/*   4:    */ import java.io.File;
/*   5:    */ import java.io.FilenameFilter;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ import java.util.Arrays;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.StringTokenizer;
/*  10:    */ import javax.swing.table.AbstractTableModel;
/*  11:    */ 
/*  12:    */ public class FileDTOTableModel
/*  13:    */   extends AbstractTableModel
/*  14:    */ {
/*  15:    */   private static final long serialVersionUID = -5983905140712682088L;
/*  16: 23 */   private List<FileDTO> list = new ArrayList();
/*  17:    */   private static final int COMMAND_COLUMN = 0;
/*  18:    */   private static final int FILE_COLUMN = 1;
/*  19:    */   private static final int PARAMS_COLUMN = 2;
/*  20:    */   
/*  21:    */   public int getRowCount()
/*  22:    */   {
/*  23: 32 */     return this.list.size();
/*  24:    */   }
/*  25:    */   
/*  26:    */   public int getColumnCount()
/*  27:    */   {
/*  28: 37 */     return COLUMN_NAMES.length;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public String getColumnName(int column)
/*  32:    */   {
/*  33: 43 */     return COLUMN_NAMES[column];
/*  34:    */   }
/*  35:    */   
/*  36:    */   public Object getValueAt(int rowIndex, int columnIndex)
/*  37:    */   {
/*  38: 51 */     switch (columnIndex)
/*  39:    */     {
/*  40:    */     case 0: 
/*  41: 53 */       return ((FileDTO)this.list.get(rowIndex)).getCommandName();
/*  42:    */     case 1: 
/*  43: 56 */       return ((FileDTO)this.list.get(rowIndex)).getFileName().getName();
/*  44:    */     case 2: 
/*  45: 59 */       return ((FileDTO)this.list.get(rowIndex)).getParams();
/*  46:    */     }
/*  47: 62 */     return null;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public FileDTO getObjectAt(int rowIndex)
/*  51:    */   {
/*  52: 68 */     return (FileDTO)this.list.get(rowIndex);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public Object getFullFileNameAt(int rowIndex)
/*  56:    */   {
/*  57: 78 */     return ((FileDTO)this.list.get(rowIndex)).getFileName().getAbsolutePath();
/*  58:    */   }
/*  59:    */   
/*  60:    */   public boolean isCellEditable(int rowIndex, int columnIndex)
/*  61:    */   {
/*  62: 83 */     switch (columnIndex)
/*  63:    */     {
/*  64:    */     case 0: 
/*  65: 85 */       return true;
/*  66:    */     case 1: 
/*  67: 88 */       return false;
/*  68:    */     case 2: 
/*  69: 91 */       return true;
/*  70:    */     }
/*  71: 94 */     return false;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void setValueAt(Object aValue, int rowIndex, int columnIndex)
/*  75:    */   {
/*  76:101 */     switch (columnIndex)
/*  77:    */     {
/*  78:    */     case 0: 
/*  79:103 */       ((FileDTO)this.list.get(rowIndex)).setCommandName(aValue.toString());
/*  80:104 */       break;
/*  81:    */     case 2: 
/*  82:107 */       ((FileDTO)this.list.get(rowIndex)).setParams(aValue.toString());
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   public void setDataSource(File dir)
/*  87:    */   {
/*  88:118 */     this.list = createFileList(dir);
/*  89:    */     
/*  90:120 */     fireTableDataChanged();
/*  91:    */   }
/*  92:    */   
/*  93:    */   private ArrayList<FileDTO> createFileList(File directory)
/*  94:    */   {
/*  95:124 */     ArrayList<FileDTO> resultList = new ArrayList();
/*  96:126 */     if ((directory != null) && (directory.isDirectory()))
/*  97:    */     {
/*  98:128 */       String[] childList = directory.list(filter);
/*  99:130 */       if (childList != null) {
/* 100:131 */         for (String s : childList) {
/* 101:132 */           resultList.add(new FileDTO(new File(directory, s)));
/* 102:    */         }
/* 103:    */       }
/* 104:    */     }
/* 105:139 */     return resultList;
/* 106:    */   }
/* 107:    */   
/* 108:145 */   private static final String[] COLUMN_NAMES = { "Command", "File", "Params" };
/* 109:147 */   public static final List<String> FILTER_FILE_EXT = Arrays.asList(new String[] { "bat", "vbs", "java" });
/* 110:149 */   public static final FilenameFilter filter = new FilenameFilter()
/* 111:    */   {
/* 112:    */     public boolean accept(File dir, String name)
/* 113:    */     {
/* 114:154 */       if (new File(dir, name).isFile()) {
/* 115:156 */         return FileDTOTableModel.FILTER_FILE_EXT.contains(parseExtension(name));
/* 116:    */       }
/* 117:159 */       return false;
/* 118:    */     }
/* 119:    */     
/* 120:    */     private String parseExtension(String fileName)
/* 121:    */     {
/* 122:163 */       StringTokenizer st = new StringTokenizer(fileName, ".");
/* 123:    */       
/* 124:165 */       String s = "";
/* 125:166 */       while (st.hasMoreTokens()) {
/* 126:167 */         s = st.nextToken();
/* 127:    */       }
/* 128:170 */       return s;
/* 129:    */     }
/* 130:    */   };
/* 131:    */ }


/* Location:           D:\.desktop\PlasticinesWorld(v.2.0.0).jar
 * Qualified Name:     com.zr.model.table.FileDTOTableModel
 * JD-Core Version:    0.7.0.1
 */