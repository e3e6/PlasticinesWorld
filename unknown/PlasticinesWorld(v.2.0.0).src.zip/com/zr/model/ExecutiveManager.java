/*  1:   */ package com.zr.model;
/*  2:   */ 
/*  3:   */ import com.zr.model.dto.Task;
/*  4:   */ import com.zr.model.table.TaskReportTableModel;
/*  5:   */ import java.io.PrintStream;
/*  6:   */ import javax.swing.JTable;
/*  7:   */ 
/*  8:   */ public class ExecutiveManager
/*  9:   */ {
/* 10:20 */   private Boolean multiThread = Boolean.valueOf(true);
/* 11:   */   private JTable view;
/* 12:   */   private TaskReportTableModel model;
/* 13:   */   private ThreadGroup tg;
/* 14:   */   public static final int UPDATE_TIMEOUT = 1000;
/* 15:   */   
/* 16:   */   public ExecutiveManager(JTable view)
/* 17:   */   {
/* 18:37 */     this.view = view;
/* 19:38 */     this.model = ((TaskReportTableModel)this.view.getModel());
/* 20:   */     
/* 21:   */ 
/* 22:   */ 
/* 23:42 */     new Thread(new Runnable()
/* 24:   */     {
/* 25:   */       public void run()
/* 26:   */       {
/* 27:   */         for (;;)
/* 28:   */         {
/* 29:50 */           ExecutiveManager.this.model.fireTableRowsUpdated(0, ExecutiveManager.this.model.getRowCount());
/* 30:   */           try
/* 31:   */           {
/* 32:53 */             Thread.sleep(1000L);
/* 33:   */           }
/* 34:   */           catch (InterruptedException e)
/* 35:   */           {
/* 36:54 */             System.err.println("Thread can't sleep");
/* 37:   */           }
/* 38:   */         }
/* 39:   */       }
/* 40:   */     })
/* 41:   */     
/* 42:   */ 
/* 43:   */ 
/* 44:   */ 
/* 45:   */ 
/* 46:   */ 
/* 47:   */ 
/* 48:   */ 
/* 49:   */ 
/* 50:   */ 
/* 51:   */ 
/* 52:   */ 
/* 53:   */ 
/* 54:   */ 
/* 55:   */ 
/* 56:58 */       .start();
/* 57:   */   }
/* 58:   */   
/* 59:   */   public void addTask(String name, String cmd)
/* 60:   */   {
/* 61:67 */     System.out.println("New task = " + name + " >> " + cmd);
/* 62:68 */     Task t = new Task(name, cmd);
/* 63:   */     
/* 64:70 */     this.model.addRow(t);
/* 65:   */     
/* 66:72 */     t.start();
/* 67:   */   }
/* 68:   */ }


/* Location:           D:\.desktop\PlasticinesWorld(v.2.0.0).jar
 * Qualified Name:     com.zr.model.ExecutiveManager
 * JD-Core Version:    0.7.0.1
 */