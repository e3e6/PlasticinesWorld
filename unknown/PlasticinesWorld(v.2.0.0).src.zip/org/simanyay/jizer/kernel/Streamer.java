/*  1:   */ package org.simanyay.jizer.kernel;
/*  2:   */ 
/*  3:   */ import java.io.BufferedReader;
/*  4:   */ import java.io.IOException;
/*  5:   */ import java.io.InputStream;
/*  6:   */ import java.io.InputStreamReader;
/*  7:   */ import java.io.PrintStream;
/*  8:   */ 
/*  9:   */ class Streamer
/* 10:   */   extends Thread
/* 11:   */ {
/* 12:   */   private InputStream input;
/* 13:   */   
/* 14:   */   public Streamer(InputStream in)
/* 15:   */   {
/* 16:55 */     this.input = in;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void run()
/* 20:   */   {
/* 21:   */     try
/* 22:   */     {
/* 23:60 */       BufferedReader reader = new BufferedReader(new InputStreamReader(this.input));
/* 24:61 */       String line = null;
/* 25:63 */       while ((line = reader.readLine()) != null) {
/* 26:64 */         System.out.println(line);
/* 27:   */       }
/* 28:   */     }
/* 29:   */     catch (IOException ioe)
/* 30:   */     {
/* 31:67 */       ioe.printStackTrace();
/* 32:   */     }
/* 33:   */   }
/* 34:   */ }


/* Location:           D:\.desktop\PlasticinesWorld(v.2.0.0).jar
 * Qualified Name:     org.simanyay.jizer.kernel.Streamer
 * JD-Core Version:    0.7.0.1
 */