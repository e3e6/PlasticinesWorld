/*  1:   */ package org.simanyay.jizer.kernel;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ 
/*  5:   */ public class Executer
/*  6:   */ {
/*  7:   */   private List<String> err_output;
/*  8:   */   private List<String> nor_output;
/*  9:   */   private int exit_value;
/* 10:15 */   private final int ARRAY = 1;
/* 11:16 */   private final int STRING = 2;
/* 12:   */   
/* 13:   */   public void execute(String cmd)
/* 14:   */     throws Exception
/* 15:   */   {
/* 16:19 */     genericExec(cmd, 2);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void execute(String[] cmd)
/* 20:   */     throws Exception
/* 21:   */   {
/* 22:23 */     genericExec(cmd, 1);
/* 23:   */   }
/* 24:   */   
/* 25:   */   private void genericExec(Object cmd, int type)
/* 26:   */     throws Exception
/* 27:   */   {
/* 28:27 */     Runtime runtime = Runtime.getRuntime();
/* 29:28 */     Process proc = null;
/* 30:30 */     if (type == 2) {
/* 31:31 */       proc = runtime.exec((String)cmd);
/* 32:32 */     } else if (type == 1) {
/* 33:33 */       proc = runtime.exec((String[])cmd);
/* 34:   */     } else {
/* 35:34 */       throw new IllegalArgumentException();
/* 36:   */     }
/* 37:36 */     Streamer err_stream = new Streamer(proc.getErrorStream());
/* 38:37 */     Streamer out_stream = new Streamer(proc.getInputStream());
/* 39:   */     
/* 40:39 */     err_stream.run();
/* 41:40 */     out_stream.run();
/* 42:   */     
/* 43:42 */     this.exit_value = proc.waitFor();
/* 44:   */   }
/* 45:   */   
/* 46:   */   public int getExitValue()
/* 47:   */   {
/* 48:46 */     return this.exit_value;
/* 49:   */   }
/* 50:   */ }


/* Location:           D:\.desktop\PlasticinesWorld(v.2.0.0).jar
 * Qualified Name:     org.simanyay.jizer.kernel.Executer
 * JD-Core Version:    0.7.0.1
 */